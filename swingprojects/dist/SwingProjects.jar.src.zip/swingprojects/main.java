/*    */ package swingprojects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class main
/*    */ {
/*    */   public static void main(String[] args) {
/* 15 */     new Snake();
/*    */   }
/*    */ }


/* Location:              F:\Work Maybe\My Fucking Projects\my-snake\My Fucking Snake.jar!\swingprojects\dist\SwingProjects.jar!\swingprojects\main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */