/*     */ package swingprojects;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Random;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.Clip;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.Timer;
/*     */ 
/*     */ public class snakePanel extends JPanel implements ActionListener, KeyListener {
/*  23 */   final int panel_hight = 600; final int panel_width = 600; final int blocksSize = 25;
/*  24 */   int blocksNumber = 576; int snakeParts = 3;
/*  25 */   int[] x = new int[this.blocksNumber];
/*  26 */   int[] y = new int[this.blocksNumber];
/*  27 */   int delay = 175; int score = 0; int xApple;
/*     */   int yApple;
/*     */   boolean running = false;
/*  30 */   char direction = 'R';
/*     */   Random random;
/*     */   Timer timer;
/*     */   
/*     */   snakePanel() {
/*  35 */     this.random = new Random();
/*  36 */     setPreferredSize(new Dimension(600, 600));
/*  37 */     setBackground(Color.black);
/*  38 */     setOpaque(true);
/*  39 */     setFocusable(true);
/*  40 */     addKeyListener(this);
/*  41 */     start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/*  46 */     apple();
/*  47 */     this.running = true;
/*  48 */     this.timer = new Timer(this.delay, this);
/*  49 */     this.timer.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintComponent(Graphics g) {
/*  58 */     super.paintComponent(g);
/*  59 */     if (this.running) {
/*  60 */       drawLine(g);
/*  61 */       draw(g);
/*     */     } else {
/*  63 */       gameOver(g);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void drawLine(Graphics g) {
/*  68 */     for (int x = 0; x < 24; x++) {
/*  69 */       g.drawLine(0, 25 * x, 600, 25 * x);
/*  70 */       g.drawLine(25 * x, 0, 25 * x, 600);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void draw(Graphics g) {
/*  75 */     for (int i = 0; i < this.snakeParts; i++) {
/*  76 */       if (i == 0) {
/*  77 */         g.setColor(new Color(0, 255, 0));
/*  78 */         g.fillRect(this.x[i], this.y[i], 25, 25);
/*     */       } else {
/*  80 */         g.setColor(new Color(0, 180, 0));
/*  81 */         g.fillRect(this.x[i], this.y[i], 25, 25);
/*     */       } 
/*     */     } 
/*  84 */     g.setColor(Color.red);
/*  85 */     g.fillOval(this.xApple, this.yApple, 25, 25);
/*     */     
/*  87 */     g.setColor(Color.red);
/*  88 */     g.setFont(new Font("Ink Free", 1, 40));
/*  89 */     FontMetrics metrics = getFontMetrics(g.getFont());
/*  90 */     g.drawString("Score : " + this.score, 230, 30);
/*     */   }
/*     */ 
/*     */   
/*     */   public void move() {
/*  95 */     for (int i = this.snakeParts; i > 0; i--) {
/*  96 */       this.x[i] = this.x[i - 1];
/*  97 */       this.y[i] = this.y[i - 1];
/*     */     } 
/*     */     
/* 100 */     switch (this.direction) { case 'U':
/* 101 */         this.y[0] = this.y[0] - 25; break;
/* 102 */       case 'D': this.y[0] = this.y[0] + 25; break;
/* 103 */       case 'L': this.x[0] = this.x[0] - 25; break;
/* 104 */       case 'R': this.x[0] = this.x[0] + 25;
/*     */         break; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void score() {
/* 111 */     if (this.x[0] == this.xApple && this.y[0] == this.yApple) {
/* 112 */       this.score++;
/* 113 */       this.snakeParts++;
/* 114 */       audio("score.WAV");
/* 115 */       apple();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void death() throws InterruptedException {
/* 120 */     if (this.x[0] < 0 || this.x[0] > 575 || this.y[0] < 0 || this.y[0] > 575) {
/* 121 */       this.running = false;
/* 122 */       gameOver();
/* 123 */       audio("lose.WAV");
/* 124 */       Thread.sleep(1000L);
/*     */     } 
/* 126 */     for (int i = this.snakeParts; i > 0; i--) {
/* 127 */       if (this.x[0] == this.x[i] && this.y[0] == this.y[i]) {
/* 128 */         this.running = false;
/* 129 */         gameOver();
/* 130 */         audio("lose.WAV");
/* 131 */         Thread.sleep(1000L);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gameOver(Graphics g) {
/* 140 */     g.setColor(Color.red);
/* 141 */     g.setFont(new Font("Ink Free", 1, 40));
/* 142 */     FontMetrics metrics1 = getFontMetrics(g.getFont());
/* 143 */     g.drawString("Score: " + this.score, 230, 230);
/*     */     
/* 145 */     g.setColor(Color.red);
/* 146 */     g.setFont(new Font("Ink Free", 1, 75));
/* 147 */     FontMetrics metrics2 = getFontMetrics(g.getFont());
/* 148 */     g.drawString("Game Over", 120, 310);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void gameOver() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void apple() {
/* 158 */     this.xApple = this.random.nextInt(24) * 25;
/* 159 */     this.yApple = this.random.nextInt(24) * 25;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 165 */     if (this.running) {
/* 166 */       move();
/* 167 */       score();
/*     */       try {
/* 169 */         death();
/* 170 */       } catch (InterruptedException ex) {
/* 171 */         Logger.getLogger(snakePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       } 
/*     */     } 
/* 174 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyPressed(KeyEvent e) {
/* 179 */     int keyCode = e.getKeyCode();
/* 180 */     switch (keyCode) { case 38:
/* 181 */         if (this.direction != 'D') this.direction = 'U';  break;
/* 182 */       case 40: if (this.direction != 'U') this.direction = 'D';  break;
/* 183 */       case 37: if (this.direction != 'R') this.direction = 'L';  break;
/* 184 */       case 39: if (this.direction != 'L') this.direction = 'R';  break; }
/*     */     
/* 186 */     audio("turn.WAV");
/*     */   }
/*     */   
/*     */   public void audio(String s) {
/* 190 */     File file = new File(s);
/*     */     try {
/* 192 */       AudioInputStream a = AudioSystem.getAudioInputStream(file);
/* 193 */       Clip c = AudioSystem.getClip();
/* 194 */       c.open(a);
/* 195 */       c.start();
/* 196 */     } catch (UnsupportedAudioFileException ex) {
/* 197 */       Logger.getLogger(snakePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 198 */     } catch (IOException ex) {
/* 199 */       Logger.getLogger(snakePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     }
/* 201 */     catch (LineUnavailableException ex) {
/* 202 */       Logger.getLogger(snakePanel.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void keyTyped(KeyEvent e) {}
/*     */   
/*     */   public void keyReleased(KeyEvent e) {}
/*     */ }


/* Location:              F:\Work Maybe\My Fucking Projects\my-snake\My Fucking Snake.jar!\swingprojects\dist\SwingProjects.jar!\swingprojects\snakePanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */